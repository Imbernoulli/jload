# Jload

```python
form jload import jload
jload(PATH)
```